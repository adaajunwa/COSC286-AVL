//TEMPLATES
// Setup templating engine in express. it will help us render our websites using templates
// we send rendered website to the client
//install pug (npm i pug)

//Require fs
const fs = require('fs');
//Require express
const express = require('express');
//Call the express function and assign it to app
const app = express();

//Start Server
let port =8080
app.listen(port, ()=>{
    console.log(`Server is started on port ${port}`);

})


// Set template type as pug
app.set('view engine', 'pug');
// Create views folder
// set folder where pug should find templates
app.set('views', `${__dirname}/Views`);


//create first.pug in the views folder

//Define Route
app.get('/', function (req, res) {
    //send template to the browser using the response render() method
    // render() takes 2 parameters -- the name of the template file,
    // and options(where you specify the variables to use within the template)
    res.render('first', { title: 'Templates' , message : 'My first template'
    });
})

//Create the header.pug and footer.bug files
//create base.pug in the views folder
//Create and render the base.pug html template to the client on the '/pug' route
// Use render() method to render templates
app.get('/base', function (req, res) {
    res.render('base', { title: 'Base Template'});
})
