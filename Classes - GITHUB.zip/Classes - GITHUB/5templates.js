//TEMPLATES
// Setup templating engine in express. it will help us render out websites using templates
// we send rendered website to the client
//install pug

//Require fs
const fs = require('fs');
//Require express
const express = require('express');
//Call the express function and assign it to app
const app = express();

//Start Server
let port =8080
app.listen(port, ()=>{
    console.log(`Server is started on port ${port}`);
})


// Set template type as pug
app.set('view engine', 'pug');
// Create views folder
// set folder where pug should find templates
app.set('views', `${__dirname}/views`);
//create base.pug in the views folder// Set template type as pug
// app.set('view engine', 'pug');
// // Create views folder
// // set folder where pug should find templates
// app.set('views', `${__dirname}/views`);
// //create first.pug in the views folder

//Define Route
app.get('/', function (req, res) {
    // send content directly to the browser (not using a template) - this can be tedious
    //res.send('hello')
    res.render('first', { title: 'Templates' , message : 'My first template'
    });
})

//Create and render the base.pug html template to the client on the '/pug' route
// Use render() method to render templates
app.get('/base', function (req, res) {
    res.render('base', { title: 'Base Template'});
})
