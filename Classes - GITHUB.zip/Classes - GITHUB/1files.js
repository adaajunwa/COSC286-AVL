// READING AND WRITING FILES
// We need to require the file system module
const fs = require('fs');
// readFileSync takes path and encoding type arguments and reads the file
const textIn = fs.readFileSync('./txt/input.txt', 'utf8')
console.log(textIn);

// writeFileSync takes path and string as arguments
// Create variable to hold output string. Use a template string with a ${} to hold variables within a string
const textOut = `This is what we know: ${textIn}.\n Created on ${Date.now()}`
fs.writeFileSync('./txt/output.txt', textOut)
console.log('file written')

/* BLOCKING AND NON-BLOCKING CODE
Blocking means execution goes one after the other. Nodejs is non-blocking by default
in the previous code example (synchronous/ blocking code), execution had to wait for each line of code
to be executed and returned before going to the next line of code.
This can be a problem with slow operations. To solve this, we use asynchronous/ non-blocking code
Here, heavy workload is offloaded to work in the background. Once the work is done, a callback function
that we previously registered, is called to handle the result. The rest of the code can continue executing
without been blocked by the heavy workload
Nodejs is single-threaded  (where the code is executed in our machine's processor), so there's only one
thread per application.
All users are accessing the same thread. so if 1 user blocks the thread, then all users would need to wait.
Avoid this by using asynchronous code with callback functions
 */