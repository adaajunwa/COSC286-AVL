// CREATE MOUNTABLE ROUTE HANDLER

//Require express
const express = require ('express')
// Require node-fetch for API fetch
const fetch = require('node-fetch');

//create a new express router object
// A Router instance is a complete middleware and routing system
const router = express.Router();

// A user defined middleware that is specific to this router
// It would run only when this route is reached
/* router.use(function timeLog (req, res, next) {
    console.log('Time: ', Date.now())
    next()
    }) */


router.get('/', function (req, res, next) {
    // send content directly to the browser (not using a template) - this can be tedious
    res.send('<html><head><title>Examples Index</title> <link rel="stylesheet" href="/bw/quartz/bootstrap.css" /></head>' +
        '<body class="container"><h1>Examples</h1><ul>' +
        '<li><a href="/examples/simple-code/">Simple Server Code examples</a></li>' +
        //TODO: Add once form-example.hbs is created
        //'<li><a href="/examples/form/">GET Simple Form Example</a></li>' +
        '</ul></body>')
})

//Render the base.pug template to the client on the '/pug' route
//To render static files, create the public folder with (css and img subfolders)
//Then in the driver file (6refactor.js) create a middleware to include static files
// Use render() method to render templates
router.get('/pug', function (req, res) {
    res.render('base', { title: 'Base Template'});
})

//Render the extendbase.pug html template to the client on the '/pug/extendbase' route
// Create the extendbase.pug template
// Use render() method to render templates
router.get('/pug/extendbase', function (req, res) {
    res.render('extendbase' , { title: 'ExtendedBase Template'});
})

//Render the firs.pug html template to the client on the '/pug/first' route
// substitute title and message with values at runtime
 router.get('/pug/first', function (req, res) {
    res.render('first', { title: 'Templates' , message : 'My first template'
    });
})

router.get('/pug/simple-code', function (req, res, next) {
    // some simple logic to generate a random number between 0 and 5
    let rnd = Math.floor(Math.random()*5);
    // call the  render function to open the simple-code template
    // in the options send in as many parameters as you want
    // the options object parameters can then be used in the template
    res.render('simple-code', {
        title: 'Simple Server Code examples', // title appears at the top the page
        myName: 'Ada Ajunwa',
        myPosition: 'Instructor',
        randomNum: rnd, // use the random number generated above to display on the page
        randomIsEven: rnd % 2 === 0, // check if the random number is even and set a boolean variable
        names: ['Aaron', 'Betty', 'Carl', 'Debby'] // arrays and objects can also be sent to the template
    })
})

//USING FETCH (with node-fetch) - 
router.get('/fetch', async function  (req, res) {

    //Ensure you read the API documentation to understand which URL to use
    const url = 'https://dog.ceo/api/breeds/image/random' //assign the API URL to variable url
    //specify the required option object properties
    const options = {
        "method": "GET", //Action type
        //body: JSON.stringify(body),
        "headers": {'Content-Type': 'application/json'} //This is used when a json object is expected
    }

//Await the result from fetch, then assign it to the response variable as a json object

    const response = await fetch(url,options)
        .then(res => res.json())
        // Catch any errors using .catch() promise (call back) and log it in the console
        .catch(e => {
            console.error({

                error: e
            })
        });
    console.log(response) // if no error, log the response

    //Pick just the url from the json object (in this case it's the message property)
    //Render the picture using the pug template (pug template should accept the imgURL variable)
    res.render('base', { title: 'Base Template', imgURL: response.message});
   })



//FETCH MULTIPLE OBJECTS IN AN ARRAY FROM AN API
router.get('/multifetch', async function  (req, res) {

    const url = 'https://dog.ceo/api/breeds/image/random/3' //gets 3 random images
    const options = {
        "method": "GET", //Action type
        //body: JSON.stringify(body),
        "headers": {'Content-Type': 'application/json'} //This is used when a json object is expected
    }
//Await the result from fetch, then assign it (res.json) to res
// Catch any errors using .catch
    const multiResponse = await fetch(url,options)
        .then(res => res.json())
        .catch(e => {
            console.error({

                error: e
            })
        });
    //Map the message attribute from the json array object
    // map() method takes a function as its parameter,this function picks the element of a
    let display  =  multiResponse.message.map((url) => {
        return `${url}`
    });
    console.log(multiResponse.message)

    //Pick just the url from the json object (in this case it's the message attribute)
    //Render the image array using the pug base template

   // res.send(display)
    res.render('multifetch', { title: 'multifetch', imgURLArray: display});

})


// Export the express router object to be used in the main js file (6refactor.js) - default export
module.exports = router;
// Then import the router object by requiring it in the main js file