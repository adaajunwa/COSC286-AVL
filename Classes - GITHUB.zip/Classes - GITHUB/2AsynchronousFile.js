//READING AND WRITING ASYNCHRONOUS FILES

// readFile() method is the asynchronous version of the readFileSync() method
// it takes path, type and callback function as arguments. The Callback function takes error message
// generated while reading the file and data to be passed into the function as arguments.
// This data is the output from reading the file

fs = require('fs');


//Read File and expect and log data when it arrives
/* fs.readFile('./txt/start.txt','utf-8',(err, data) => {
if (err) return console.log('ERROR!!')
    console.log(data)
});
console.log('Will write file'); */

// Using callback functions within callback functions
// Read the start.txt and execute the callback using its output as input data
 /* fs.readFile('./txt/start.txt','utf-8',(err, data) => {
    // use the input data as the filename and execute the callback function
    fs.readFile(`./txt/${data}.txt`,'utf-8',(err, data1) => {
        console.log(data1)
    })
});
console.log('Will write file'); */


// Even deeper nested callback functions
// Read the start.txt and execute the callback using its output as input data
/*** fs.readFile('./txt/start.txt','utf-8',(err, data) => {
    // use the input data as the filename, read and store it in data1 and execute the callback function
    fs.readFile(`./txt/${data}.txt`,'utf-8',(err, data1) => {
        console.log(data1)
        // Read the append.txt and execute the callback using its output as input data2
        fs.readFile(`./txt/append.txt`,'utf-8',(err, data2) => {
            console.log(data2)
            // writeFile writes a string to a given file, it takes 4 arguments. Since it doesn't output anything,
            // the callback function doesn't need to take any data input, just the possible error message. The appended
            // text from data1 and data2 are written to final.txt, with a newline in between them.
            // fs.writeFile('./txt/final.txt',`${data1}\n${data2}`,'utf-8',(err) => {
                 //console.log('Your file has been written')
            // })
            fs.writeFile('./txt/final.txt',`${data1}\n${data2}`,'utf-8',(err) => {
                console.log('Your file has been written')
            })
        })
    })
});
console.log('Will write file'); ***/

// Excessive nesting of Callback function can lead to a phenomenon called callback hell.
// We fix this using promises.
// create a function that takes a filename and returns a promise
// We are just creating a new function readFilePromise which runs the readFile function,
// but returns a promise, so we can use this promise instead of the callback function
// The resolve and reject arguments of the promise are also functions of their own
// Calling the resolve function marks the promise as successful, and returns the successful values from the promise
// i.e. whatever is passed as an argument in the resolve function will be later available as the
    // argument to the .Then() method. Also, calling the reject function marks the promise as rejected if there was an error
    // whatever we pass into the reject function will be the error message
    //The promise constructor takes in an executor function which gets called immediately when the promise is created
    //This is where all the asynchronous work is done


 const readProFile = file =>{
        return new Promise((resolve, reject) => {
            //read the file asynchronously
            fs.readFile(file, 'utf8', (err, data) => {
                if (err) {
                    reject('I could not find file');
                }
                resolve(data); //returns data passed from the promise
            })
        })
    }

 /***  readProFile('./txt/start.txt').then(data => {
       console.log(data);
       return   data1 = readProFile(`./txt/${data}.txt`);
    }).then(data1 => {
       //console.log(data1);
         let data2 = readProFile(`./txt/append.txt`);
         console.log(data1);

   }) ****/

//There is an even more recent way (async/ await)
// Async shows that code within the function are asynchronous promises
// When execution gets to await, it stops, executes the promise, and saves the result in a variable
const test = async (req, res) => {
    const data = await readProFile('./txt/start.txt');
    console.log(data);
    //output from previous await promise is used as an input for next await promise
    const data1 = await readProFile(`./txt/${data}.txt`);
    console.log(data1);
    const data2 = await readProFile(`./txt/append.txt`);
    console.log(data1 +'\n'+ data2);
    fs.writeFile('./txt/final.txt',data1 +'\n'+ data2,'utf-8',(err) => {
        console.log('Your file has been written')
    })
}
//Call async function to execute code
test()