// Create a folder named routes
// create a product.js, example.js and user.js files under it

// USING EXPRESS
//Require file system (fs)
const fs = require('fs');
// Require the body-parser function
const bodyParser = require('body-parser');


// Require the express function
const express = require('express');

//Call the express function and assign it to app
const app = express();

//Import the Router from the example.js file
const exampleRouter = require('./Routes/example.js');

//Import the Router from the user.js file
const userRouter = require('./Routes/user.js');

//Import the Router from the 7multer.js file
const uploadRouter = require('./7multer.js');

//Import the Router from the 8validation.js file
const validationRouter = require('./8validation.js');


//Start a Server
// listen method takes port, host IP and callback function as arguments
let port =8080
app.listen(port, ()=>{
    console.log(`Server started on port ${port}`);
})

// MIDDLEWARES
// Middleware functions are functions that have access to the request object (req), the response object (res),
// and the next middleware function in the application’s request-response cycle.
// The next middleware function is commonly denoted by a variable named next.
// It is used to execute code or make changes to the request and the response objects.
// You can create your own middleware, or use a third-party middleware
// The use method of an express object is used to define a middleware
// app.use middleware would run for each defined route
// User defined middleware are written as seen below:

/*
app.use((req, res, next) => {
  console.log('Time:', Date.now())
  next()
})
 */


//Create a bodyParser middleware to parse the posted body
app.use(bodyParser.urlencoded({ extended: false })) // for form elements
app.use(bodyParser.json()) // for json objects (APIs)

// CREATE MIDDLEWARE TO INCLUDE  STATIC FILES
//'/image' is the alias name for your url route from the working directory (--dirname)
//'/public/img' is the exact file path
// Serve static files directly in browser with a path alias (127.0.0.1:8080/image/leo.jpg
app.use('/image', express.static (__dirname+'/public/img'));
app.use('/css', express.static (__dirname+'/public/css'));
// OR you could include static files directly from the public folder with this format
// Serve static files directly in browser (127.0.0.1:8080/img/leo.jpg)
app.use(express.static (__dirname+'/public'));


//DEFINE ROUTES
//create express routers as middlewares for the routes
//Middleware is a function that can modify the incoming request data

//app.use('/product', productRouter)
app.use('/example', exampleRouter)
app.use('/user', userRouter)
app.use('/upload', uploadRouter)

app.use('/validation', validationRouter)
//app.use('/signup', signupRouter)


// TEMPLATES
//set up view engine for html templates
// Set template type as pug
app.set('view engine', 'pug');
// Create views folder
// set folder where pug should find templates
app.set('views', `${__dirname}/views`);
//create base.pug in the views folder





