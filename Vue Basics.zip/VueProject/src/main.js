// Import the main.css file
import './assets/main.css'

// Import the createApp function from vue
import { createApp } from 'vue'
//import the App component from './App.vue'
import App from './App.vue'
//Import the router function from index.js
import router from './router'

//createApp creates an instance of an application. It takes a root component, and optional props
// create an instance of the App.vue application
const app = createApp(App)

// creates a router middleware
app.use(router)

//The createApp function from the vue library will mount the App component
// On the Dom node with attribute "id" called app
app.mount('#app')
