// USING COOKIES

// Cookies and sessions are used by websites to store users' data across different pages
// of the site.The key difference between sessions and cookies is that sessions are
// saved on the server side while cookies are saved on the client side.
// To Use Cookies, you must install and require cookie-parser
// Install cookie-parser (npm i cookie-parser)


//Require express
const express = require ('express')
//create an express router
const router = express.Router();
// require cookieParser
const cookieParser = require('cookie-parser');

// use the cookieParser middleware
router.use(cookieParser());

//Create Route handlers to test the cookies
// When the /cookie route is reached, the server sends back a cookie to be set in the client browser
router.get('/', function (req, res, next) {

    // create a cookie i.e. set a cookie in the response object
    // cookie function takes the cookie name, value, and options.
    // I have added an expiration of 5 minute (60000 * 5 ms)
    //Cookie is not parsed, so we install and require cookie-parser
    //Also ensure you use  it (the middleware) before the routes ()
    // now cookieParser can parse the cookie
    res.cookie('cookieName', 'New Cookie', { maxAge: 60000 * 5});
    res.cookie('cookieEmail', 'New@Cookie.ca', { maxAge: 60000 * 5});
    // render a template file directly to the browser
    res.render( 'base');
})

//Subsequently, as long as the cookie is still available in the client browser, its values can be used within any route
// Subsequently, when cookie/request route is reached by the client browser, we confirm its the right cookie,
// And display the name of the cookie in a form input


router.get('/request', function (req, res, next) {
    // Send the cookie back to server with the request i.e. in the request object
    // console log the cookie property in the request object header
    console.log(req.headers.cookie)

    // console log the parsed cookie
    console.log(req.cookies)
    console.log(req.cookies.cookieName)
    // if the cookie exists and it has the right value render the page
    if (req.cookies.cookieName && req.cookies.cookieName === 'New Cookie' && req.cookies.cookieEmail === 'New@Cookie.ca') {
        res.render('pugForm', { title: 'Show Cookie' , name : req.cookies.cookieName, email: req.cookies.cookieEmail
        });
    }
    //else send back an error message
    else {
        res.send('You cannot view this page');
    }
})
module.exports = router;