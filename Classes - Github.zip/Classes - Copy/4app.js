// USING EXPRESS


const fs = require('fs');
// Require express i.e Instantiate a new express object
const express = require('express');
//Call the express function and assign it to app
const app = express();
// Require node-fetch for API fetch
const fetch = require('node-fetch');

//Start a Server
// listen method takes port as arguments, an optional host IP (when no host is entered the default local IP is used)
// and callback function that specifies what to do when the server starts
let port =8080
app.listen(port, ()=>{
    console.log(`Server started on port ${port}`);
})

//DEFINE ROUTES
// Routing means defining how an application responds to a particular client request
// i.e. to a specific URL
// It takes the path and a callback (request, response) function as arguments.
// The call back function specifies what should happen when the request reaches that URL
//The request and response are objects

/*  app.get(path, function(req,res){
    })
 */

//Send a request to the client using the get() method
//Send a Html response to the client

app.get('/', function (req, res) {
    // send html content directly to the browser (not using a template) - this can be tedious
    res.send('<html><head><title>Examples Index</title></head>' +
        '<body <h1>Examples</h1><ul>' +
        '<li><a href="/text">Simple Server Code example</a></li>' +
        '</ul></body>')
})

//Send a text response to the client
app.get('/text', function (req, res) {
    // send text content directly to the browser (not using a template) - this can be tedious
    res.send('Hello Tester')
})

// Send a json response to the client
app.get('/json', function (req, res) {
    res.json({message: 'Hello json Page', details:'We are learning to route'});
})


//Read JSON file and convert it into a javascript object
const tours = JSON.parse(fs.readFileSync(`${__dirname}/data/tours-simple.json`));
// Send a json object response to the client
app.get('/api/json', function (req, res) {
    res.status(200).json({
        status: 'success',
        data: {tours: tours}
    });
})


//USING FETCH (with node-fetch)
// First install the node-fetch module v2 (npm i node-fetch@2)
// then require 'node-fetch' as fetch at the top of code
// node-fetch is an asynchronous function that requires a url and an options object as argument
app.get('/fetch', async function  (req, res) {

    const url = 'https://dog.ceo/api/breeds/image/random'
    const options = {
    "method": "GET", //Action type
    //body: JSON.stringify(body),
    "headers": {'Content-Type': 'application/json'} //This is used when a json object is expected
}
//Await the result from fetch, then assign it (res.json) to res
// Catch any errors using .catch
const response = await fetch(url,options)
    .then(res => res.json())
    //console.log(res.json)
   // })
    .catch(e => {
        console.error({
            "message": "Oh No!",
            error: e
        })
    });
console.log(response)
    //Send the json object as a response
    //res.json(response)
    //Send just the url from the json object (in this case it's the message attribute)
    res.send(response.message)

})


// We run our file using 'nodemon [filename]'
// Install postman and test same thing on postman

