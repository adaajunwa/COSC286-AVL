// Create a folder named routes
// create a product.js, example.js and user.js files under it

// USING EXPRESS
//Require file system (fs)
const fs = require('fs');
// Require the body-parser function
const bodyParser = require('body-parser');

//Require express-session
const session = require('express-session');
//Require passport
const passport = require('passport');

// Require the express function
const express = require('express');

//Call the express function and assign it to app
const app = express();

//Require cors
const cors = require("cors")

//use the cors function
app.use(cors())

//Require dotenv for the .env config file
require('dotenv').config()

// Require mongoose
const mongoose = require('mongoose');

//Import the connectDB function from the 9VMongoDB.js file
const connectDB = require ('./9VMongoDB.js');

//Import the Router from the employees.js file
const employeeAPIRouter = require('./Routes/employees.js');

//Import the Router from the example.js file
const exampleRouter = require('./Routes/example.js');

//Import the Router from the user.js file
const userRouter = require('./Routes/user.js');

//Import the Router from the 7multer.js file
const uploadRouter = require('./7multer.js');

//Import the Router from the 8validation.js file
const validationRouter = require('./8validation.js');

//Import the Router from the 8Acookies.js file
const cookieRouter  = require('./8Acookies.js');

//Import the Router from the 8Bsessions.js file
const sessionRouter  = require('./8Bsessions');

//Import the Router from the 8Cpassport.js file
const passportRouter  = require('./8Cpassport.js');

//Import the Router from the 9tokens.js file
const signupRouter = require('./9tokens.js');

//Import the Router from the product file
const productRouter = require('./Routes/product.js');


// Connect to MongoDB
connectDB()

//Update the listener code: Open the MongoDB connection and Start a Server
//connection.once() signifies that the event will be called only once i.e. the first time when the connection is opened
//it will not occur once per request, but rather once when the mongoose connection is made with the db
// The connection.once() method takes 2 parameters (and "open" value and a function that controls what happens
// when the connection opens
mongoose.connection.once('open', function(){
    console.log('MongoDB Connected');
    // listen method takes port, host IP and callback function as arguments
    let port =8080
    app.listen(port, ()=>{
        console.log(`Server started on port ${port}`);
    })
})

/* let port =8080
app.listen(port, ()=>{
    console.log(`Server started on port ${port}`);
}) */

// MIDDLEWARES
// Middleware functions are functions that have access to the request object (req), the response object (res),
// and the next middleware function in the application’s request-response cycle.
// The next middleware function is commonly denoted by a variable named next.
// It is used to execute code or make changes to the request and the response objects.
// You can create your own middleware, or use a third-party middleware
// The use method of an express object is used to define a middleware
// app.use middleware would run for each defined route
// User defined middleware are written as seen below:

/*
app.use((req, res, next) => {
  console.log('Time:', Date.now())
  next()
})
 */


//Create a bodyParser middleware to parse the posted body
app.use(bodyParser.urlencoded({ extended: false })) // for form elements
app.use(bodyParser.json()) // for json objects (APIs)

// CREATE MIDDLEWARE TO INCLUDE  STATIC FILES
//'/image' is the alias name for your url route from the working directory (--dirname)
//'/public/img' is the exact file path
// Serve static files directly in browser with a path alias (127.0.0.1:8080/image/leo.jpg
app.use('/image', express.static (__dirname+'/public/img'));
app.use('/css', express.static (__dirname+'/public/css'));
// OR you could include static files directly from the public folder with this format
// Serve static files directly in browser (127.0.0.1:8080/img/leo.jpg)
app.use(express.static (__dirname+'/public'));


app.use(session({
    secret: "this is a secret key",
    saveUninitialized: false, //do not save uninitialised sessions to memory.
                              // A session is uninitialized when it is new but not modified.
                              // Choosing false is useful for implementing login sessions,
                              // reducing server storage usage
    resave: false, //do not resave unmodified sessions back to store
    cookie:{
        maxAge: 60000 * 10
    }
}))

// initialize the passport and passport session middlewares
app.use(passport.initialize());
app.use(passport.session())

//DEFINE ROUTES
//create express routers as middlewares for the routes
//Middleware is a function that can modify the incoming request data

app.use('/api', employeeAPIRouter)
app.use('/product', productRouter)
app.use('/example', exampleRouter)
app.use('/user', userRouter)
app.use('/upload', uploadRouter)

app.use('/validation', validationRouter)
app.use('/cookie', cookieRouter)
app.use('/session', sessionRouter)
app.use('/passport', passportRouter)
app.use('/signup', signupRouter)

app.use('/product', productRouter)

//app.use('/signup', signupRouter)


// TEMPLATES
//set up view engine for html templates
// Set template type as pug
app.set('view engine', 'pug');
// Create views folder
// set folder where pug should find templates
app.set('views', `${__dirname}/views`);
//create base.pug in the views folder





