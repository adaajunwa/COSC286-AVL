// SERVER-SIDE VALIDATION
// Install express-validator (npm i express-validator) and require express-validator
//Create a html validation form
// create a /validation route in 6refactor.js and refactor here
// Setup public css and client.js files (if  needed)
// Ensure body-parser is required



//Require express
const express = require ('express')
//create an express router
const router = express.Router();
// Require path
const path = require('path');
//Require express-validator it is a middleware
// assign the validator object using destructuring
// const {check, query, ValidationResult} = require ('express-validator')
// The check variable checks for posted request body values,
// query variable checks for get request query values
//validationResult extracts the validation errors from a request
// and makes them available as an object
const {check, query, validationResult} = require ('express-validator')
//Require bodyParser
const bodyParser = require('body-parser');

//Create a bodyParser middleware to parse the posted body
// We don't need this again since it was done in the main app file (its a reminder that its needed)
router.use(bodyParser.urlencoded({ extended: false }))
// So we can parse the res.json array to return only the validation message
router.use(bodyParser.json())

//Create Validation Chain Checks
// Always sanitize using .trim() before validating
// .bail() Stops running validations if any of the previous ones have failed.
// []

const bodyCheck = [
        check('name')
            .trim()
            .not().isEmpty() // not empty
            .withMessage('Please enter a name')
            .bail()   //Demo .bali
            .isLength({min: 3, max: 50})
            .withMessage('Name must be between 3 and 50 characters')
            .isAlpha() // only alphabets -- no special characters
            .withMessage('Name must contain only alphabets'),
        check('email')
            .not().isEmpty()
            .withMessage('Please enter Email')
            .isEmail()
            .withMessage('Invalid Email'),
        // check phone
        check('phone')
            .trim()
            .not().isEmpty()
            .withMessage('Please enter phone number')
            .isInt() // only digits -- no special characters
            .withMessage('Phone number must be digits only')
            .isLength({min: 10, max: 10}) //Exactly 10 characters
            .withMessage('Phone number must be 10 digits'),
        //Check that radio button yes is selected
        check('age')
            .equals('yes')
            .withMessage('You must be 18 or more'),

         //Custom Validation
         //custom validation function should return true, if it returns false,
         // it throws an error
          check('name').custom((value) => {
              // Convert name value to lower case
               value = value.toLowerCase()
              //A string's search() method returns the index of the argument if found
              // If the first letter is a, return true
              return value.search("a") === 0
          }).withMessage('Name should start with an A'),

//Assignment zipcode
        //   check('zipcode')
        //      .isPostalCode('CA')
    ]

//DEFINE ROUTE HANDLER

//When user accesses this path, send the validationForm.html file
// Create the validationForm.html file with a post method, and /validation action
router.get('/',  function (req, res, next) {
    // send html file directly to the browser
    res.sendFile( `${__dirname}/Routes/validationForm.html`);
})

// Validate the request body elements sent from validationForm.html post method
// The bodyCheck validation chain acts as a middleware to the post sub-route
router.post('/', bodyCheck,  (req, res, next)  => {

//validationResult extracts the validation errors from a request
// and makes them available in a Result json object
    const errors = validationResult(req);
    //if errors exist
    if (!errors.isEmpty()) {
        console.log(errors.array())
        //return status 422 and errors array as a json object (API)
        return res.status(422).json({
            errors: errors.array()});
    }
    //console log the name that was sent via the form

    console.log(req.body.name);
    // send response to the client to complete the request response cycle
    res.send( 'Validation Successful');
})



// Render the pugForm.pug file when the request hits the given sub-route
//Create the pugForm.pug file with a get method and /validation/queryMsg action
router.get('/query', function (req, res, next) {
    // send html file directly to the browser
    res.render( 'pugForm');
})

// Validate the queries sent from pugForm's get
// Include a validation chain as a middleware to the get sub-route
router.get('/queryMsg', [
    query('name')
        .trim()
        .not().isEmpty()
        .withMessage('Please enter a name')
        //.bail()
        .isLength({min: 3, max: 50})
        .withMessage('Name must be at least 3 characters')
        .isAlpha()
        .withMessage('Name must contain only alphabets'),
    query('email')
        .not().isEmpty()
        .withMessage('Please enter Email')
        .isEmail()
        .withMessage('Invalid Email'),
], (req, res, next)  => {

//validationResult extracts the validation errors from a request and makes them available in a Result object
    const errors = validationResult(req);
    //if errors exist
    if (!errors.isEmpty()) {
        //return status 422 and errors array as a json object (API)
        return res.status(422).json({
            errors: errors.array()});
    }
    console.log(req.query.email);
    // send response to the client to complete the request response cycle
    res.send( 'Query Validation Successful');
})


module.exports = router;