//Require express and fs
const express = require ('express')
const fs = require('fs');

//create an express router
const router = express.Router();
//Require jsonwebtoken
//const jwt = require('jsonwebtoken')

//Import the JWT Authenticator from the auth.js file
const cookieJwtAuth = require('../auth.js');

//Create a middleware to ensure only users with the jwt token cookie can
// access the /product sub route

/*exports.cookieJwtAuth = (req, res, next) => {
    const token= req.cookies.token;
    try {
        const user = jwt.verify(token, process.env.SECRET);
        req.user = user;
        next()
    } catch{
        res.clearCookie('token');
        return res.redirect('/signup');

    }
} */




router.get('/users', cookieJwtAuth, function (req, res, next) {
    // send html file directly to the browser
    res.render( 'products');
    //console.log(req.headers);

})

router.get('/unauthorized',function (req, res, next) {
    // send html file directly to the browser

    res.sendFile( `${__dirname}/unauthorized.html`);
})
module.exports = router;