//REFACTORING STEPS IN THE APPS FILE

//Require  everything you need for the refactored route handler to function properly
// fs, express, node-fetch, etc
// assign express() function to app
// Import the express Router from the route handler file (e.g. example.js file)
// and assign it to a constant
// Start a Server
// Define main routes as middleware (app.use('/example', exampleRouter))
// Note that exampleRouter is the constant holding the example router object 
// If you are using Templates, set up your template view engine
// and set up the path to the template files


//Require file system (fs)
const fs = require('fs');
// Require the express function
const express = require('express');

//Call the express function and assign it to app variable
const app = express();

// Require node-fetch for API fetch
const fetch = require('node-fetch');

//Import the Router from the example.js file
const exampleRouter = require('./Routes/refactor.js');


//START A SERVER
// listen method takes port, host IP and callback function as arguments
let port =8080
app.listen(port, ()=>{
    console.log(`Server started on port ${port}`);
})


//ROUTE MIDDLEWARE
app.use('/refactor', exampleRouter)


// TEMPLATES
//set up view engine for html templates
// Set template type as pug
app.set('view engine', 'pug');
// Create views folder
// set folder where pug should find templates
app.set('views', `${__dirname}/views`);
//create base.pug in the views folder