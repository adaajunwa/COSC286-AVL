// Using SESSIONS

// sessions represent the duration of a user on a server.
// They are used to track specific users making requests
// a session ID is created by the server and sent back as a cookie
// so that a specific user is always known by their session ID
// cookie with session id is then parsed and verified on the server,
// and the proper page is rendered to the user
// e.g ecommerce sites that track what users had in their carts

// Install express session package (npm i express-session)
// require express-session and use the middleware before the route endpoints
//A session refers to a way of maintaining state information about a user’s interactions with a website
// or web application. When a user visits a website, the server can create a session for that user.
// Additionally, a session allows the server to keep track of information such as the user’s login status,
// preferences, and any data entered into forms.
// The server typically initiates a session when a user logs in to a website.
// Furthermore, we can identify a session by a unique session ID. Generally, we pass the session IDs
// as a parameter in URLs or store them in the cookies. The session ID allows the server to associate
// the user’s requests with their specific session.
// Additionally, it also helps to retrieve and update the session data as required.


//Require express
const express = require ('express')
//create an express router
const router = express.Router();

// Install express-session
// In your main app.js file, Require express-session (const session = require('express-session'))
// Then use the session middleware

//Import the mockUser  from the Users.js file
const mockUsers = require("./Users");

//CREATE THE ROUTES
router.get('/', function (req, res, next) {
    //console log the session from the request object
    console.log(req.session)
    //console log the session ID from the request object
    console.log(req.session.id)
    // each time we request this endpoint a new session and session id is created
    // this is not good for tracking users. we need to wrap the session id as visited
    // so it doesn't change until the cookie expires

    // modifiy the session by setting our session id to visited (req.session.visited = true)
    req.session.visited = true
    // send html file directly to the browser
    res.render( 'base');
})


router.get('/request', function (req, res, next) {
    // console log session and session id in request object header
    // As long as we do not restart our server (because we are not storing our session), session id remains the same
    // Note that nodemon restarts our server whenever we edit something
    //console.log(req.session)
    console.log(req.session.id)
    res.render('base');


})

// MAP A SESSION ID TO A USER (from User.js) IN OUR APP
// remember to import the mockUser function from User.
// We will use an API (json object) to post user credentials
// mockUser holds an array of user objects . it was created as a mock user database table

router.post('/api/auth', function (req, res, next) {
    //Deconstruct the username and password from the request body
    const {username, password} = req.body;
    //I will not validate here
    //Find the user and password from mockUsers, make sure they exist
    //find() takes a predicate function (returns boolean).
    // The argument for that function in this case is user
    // If a username in the mockUser array matches the username passed in the request body,
    // it returns the array element (object) that contains the username passed in the request body
    // ensure app.use(bodyParser.json()) middleware is included to parse the json API request body
    const findUser = mockUsers.find((user) => user.username === username);
    // If user object is not found return status 401 (unauthenticated)
    if (!findUser || findUser.password !== password) {
        return res.status(401).send('User Not Found');
}
// log the request session so we see what it contains (no user property)
console.log(req.session);

// Assign the user object that was authenticated to the user property in the request session.
// Set a user property in the session cookie as the authenticated user
req.session.user = findUser;
// log the request session so we see what it contains
// (now has a user property that we can use to ensure its the same user)
    console.log(req.session);
// send back the authenticated user as a response
return res.status(200).send(findUser);
})

// Test in postman: post user credentials as json object in body.
// Remember to surround the properties and values in ""
// when session id cookie expires access is denied

// TEST OUT MAPPING SESSIONS FOR USER CART ITEMS
// Note that with this demo, when the server restarts you need to reauthenticate the user from /api/auth route
// since the api/cart route does not authenticate users (we are currently not saving sessions)
router.post('/api/cart', function (req, res, next) {
    // If the user session dosen't exist i.e. user authentication has not occurred
    // and user property not set

    if (!req.session.user) {
        return res.status(401).send('You need to log in!!');
    }
    //deconstruct the request body and pick item
    const item = req.body;
    //Create the cart object in the request session
    const {cart} = req.session
    //If the cart object exists, add the new item to the cart object
    if (cart) {
       cart.push(item);
    }
    else {
        //Add it as the first array object in the cart
        req.session.cart = [item];
    }
    console.log(req.session);
    console.log(cart)
    //return the item
    return res.status(201).send(item);

})
module.exports = router;