// NODE.JS
//Download and install node.js (nodejs.org)
// Test if node was properly installed. In the terminal (node -v)
// node.js allows us to run javascript without a browser
//To run JS input 'node' in terminal, then test with console.log('hello')
// We can also run js files in node.js

let hello = "Hello World";
console.log(hello)

// Use .exit or ctrl C to exit, then type node index.js to run the index file