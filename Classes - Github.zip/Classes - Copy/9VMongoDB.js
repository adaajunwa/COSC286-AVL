// MongoDB a NOSQL database stores data in collections not in relations like in an RDBMS
// Individual records in a collection are called documents
// They have a key/ value structure like JSON
// MongoDB is great for performance, flexibility and scalability

// Create a free MongoDB account (mongodb.com)

// Create a project then deploy your cluster

// On the Deploy Cluster Page ensure you pick "free"
// Change your cluster name if you want, and click "CREATE DEPLOYMENT"
// On the "Connect to Cluster" page,  Click Add Network Access
// On the Network Access page, click on Add IP Address
// Click on "Allow Access from Anywhere" (database would be available from any device)
// DO NOT ATTEMPT THE ABOVE IN A PRODUCTION ENVIRONMENT

// Specify a database user and password, Click Create Database User, then click "Choose a Connection Method"
// On the Connect to Cluster page, click on Drivers
// Copy your connection string, and click Done

// Click on projects to view your projects page
// On the Project Overview page, scroll down to Data Management
// Click on Browse Collections and Click on Add My Own Data
// Add a Database Name and a Collection name (similar to Table in RDBMDs)

// Install mongodb (npm install mongodb)
//Install mongoose (npm i mongoose) mongoose is an ORM that makes working with mongoDB much easier
// WE WOULD USE A .ENV FILE (npm install dotenv)
// Create a .env file at the project root to save your connection string
// Add the connection string to the .env file
// in the .env file, update the password with the MongoDB password,
// and add the database name after "....mongodb.net/...."
// You must require the .env config in the main app.js file

// Create a Model folder under the project folder to store data models
// Create an employee.model.js file to create the employee schema and model


const mongoose = require('mongoose');
require('dotenv').config();

//Connect to Mongodb via mongoose
// mongoose.connect() takes the connection string and an options object
// the options object properties set to true to prevent us from getting warnings from MongoDB
const connectDB = async() => {
    try {
        await mongoose.connect(process.env.DB_Connect);

    } catch (e) {
        console.log(e);
    }
}

module.exports = connectDB;
// Ensure connectDB and mongoose are required in the main app.js file
// and connect to the MongoDB database by calling this connection module (connectDB())

