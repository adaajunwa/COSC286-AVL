//CREATE the Employee Schema and Model

//Require mongoose ORM
const mongoose = require('mongoose');

//Create an Employee Schema
const EmployeeSchema = mongoose.Schema(
    {
        name:{
            type: String,
            required: [true, "Please enter a name"],
        },
        email:{
            type: String,
            required: [true, "Please enter a valid email"],
            unique: true
        },
        age:{
            type: Number,
            required: false,
        },
        Salary:{
            type: Number,
            required: true,
            default: 200
        }
    },
    {
        timestamps: true, // creates 2 other fields for Created At and Updated At
    }
)

//Create the Employee Model for exportation
const Employee = mongoose.model("Employee", EmployeeSchema)

// Export the Employee model
module.exports = Employee

// Create an employee.js route handler for creating/updating/filtering and sorting employees (api/employee)
// Ensure you require the exported Employee model in the employee.js route handler
