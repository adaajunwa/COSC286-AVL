// Create Mock users, an array of user objects
const mockUsers = [
    { id: 1, username: 'john', password: '123456' },
    { id: 2, username: 'paul', password: '123456' },
    { id: 3, username: 'pete', password: '123456' },
    { id: 4, username: 'sally', password: '123457' }
];

//Export mockUsers
module.exports = mockUsers;