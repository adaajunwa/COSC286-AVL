import './assets/main.css'

import { createApp } from 'vue'
import { createRouter, createWebHistory } from 'vue-router'
import App from './App.vue'
import RouteA from './components/RouteA.vue'
import RouteB from './components/RouteB.vue'

const router = createRouter({
    history: createWebHistory(),
    routes: [
        { path: '/routeA', component: RouteA },
        { path: '/routeB', component: RouteB },
    ]
});

//createApp creates an instance of an application. It takes a root component, and optional props
// create an instance of the App.vue application
const app = createApp(App) //

// creates a router middleware
app.use(router);

//The createApp function from the vue library will mount the App component
// On the Dom node with attribute "id" called app
app.mount('#app')