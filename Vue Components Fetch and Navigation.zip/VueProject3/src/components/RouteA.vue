<script setup>

</script>

<template>
  <h1>Activities!</h1>
  <h2><p>I love dancing.</p></h2>
</template>

<style scoped>

</style>