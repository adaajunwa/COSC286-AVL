<template>
  <div>
    <h1>---------------------------------------------</h1>
<h1>Employee Data Form</h1>

  <form  v-on:click="sendData" >

    <div >
      <label for="name" >Name  </label>
      <input type="text" name="name" id="name" v-model="formValues.name">
    </div>
    <div >
      <label for="password" >Email   </label>
      <input type="email" name="email" id="email"  v-model="formValues.email">
    </div>
    <div >
      <label for="Salary" >Salary   </label>
      <input type="text" name="Salary" id="Salary"  v-model="formValues.Salary">
    </div>
    <div >
      <button  type="submit" id="postbtn">Post Data</button>
    </div>

  </form>
</div>
</template>

<script>
export default {
  name: 'PostData',
  data () {
    return {
      //Return form data
      formValues: {
        name: '',
        email:'',
        Salary:'',
      }
    }
  },
  methods: {
    // Create send method to post data. Assign to button onClick event
    sendData(e) {
  // Cancel the default action of the onsubmit event (e).
  e.preventDefault()
  //Specify form data for API post
  let params ={
    headers:{'Content-type':'application/json'},
    body: JSON.stringify({
      name: this.formValues.name,//('name'),
      email: this.formValues.email,//('email'),
      Salary: this.formValues.Salary, //('Salary'),

    }),
    method: "POST"
  }

  //Use fetch to post the form data
  fetch('http://127.0.0.1:8080/api/employee', params)
      .then((response) => response.json()) // Returns the json response promise object
      .then((data) => console.log(data)) //console log the response json object

      .catch(err=> console.log(err)) // Catch and log the error
}
  }
}
</script>

<style scoped>

</style>