<script setup>

</script>

<template>
  <h1>Movies!</h1>
  <h2><p>Comedies, sci-fi, and fantasy are my best movies</p> </h2>
</template>

<style scoped>

</style>