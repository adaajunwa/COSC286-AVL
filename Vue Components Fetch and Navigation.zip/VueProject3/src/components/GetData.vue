<template>
  <div>
    <h1>---------------------------------------------</h1>
    <button @click ="fetchData"> Get Data</button>
    <h1 v-if="data"> Looping Through Fetched Employee Data</h1>
    <h2 v-for ="emp in data">{{emp.name}}'s email is {{emp.email}}: {{emp.name}} earns {{emp.Salary}}</h2>
  </div>
</template>


<script>
import {ref} from 'vue'
export default {
  name: 'GetData',
  data () {
        return {
       data: null,

    }
  },
  methods: {
    async fetchData() {
      const response = await fetch("http://localhost:8080/api/employee");
      this.data = await response.json();
    }
  }
}
</script>




<style scoped>

</style>