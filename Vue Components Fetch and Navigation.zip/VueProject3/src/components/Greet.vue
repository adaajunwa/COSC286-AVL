<template>
  <!-- 1st <h2> Hello Ada</h2> -->
  <h2> Hello! {{ name }} goes to {{location}}</h2>
</template>

<script>
export default {
  name: 'Greet', //Give the component export a name
  props: ['name', 'location'],
}
</script>

<style>

</style>