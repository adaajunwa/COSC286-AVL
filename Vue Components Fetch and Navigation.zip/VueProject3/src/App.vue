

<template>
  <div>
    <h1>Choose The Page You Want To See</h1>

     <h2><router-link to="/routeA">Activities</router-link> </h2>
      <h2><router-link to="/routeB">Movies</router-link></h2>
    <br>
    <router-view></router-view>
   </div>

  <br>

  <div>
  <h1>Components are Dynamic with Props ...</h1>
  <br>
  <Greet name = "Sally" location = "School"></Greet>
  <br>
  <Greet name = "Ben" location = "Mexico"></Greet>
  <br>
  <h1>Using Dynamic data properties with Props ...</h1>
  <br>
  <Greet v-bind:name = "name" v-bind:location = "location"></Greet>
  </div>

  <br>
  <GetData> </GetData>
  <br>
  <PostData> </PostData>

</template>

<script>
import Greet from './components/Greet.vue'
import GetData from './components/GetData.vue'
import PostData from './components/PostData.vue'

export default {
  name: 'App',
  components: {
    Greet,
    GetData,
    PostData,
  },
  data(){
    return{
      name: 'Pete',
      location: 'Brazil',

    }
  }
}
</script>


<style scoped>
button {
  padding: 5px;
  margin: 10px;
}
div {
  border: dashed black 1px;
  padding: 10px;
  display: inline-block;
}
</style>
