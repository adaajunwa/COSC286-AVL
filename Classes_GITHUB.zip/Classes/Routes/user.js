//Require express
const express = require ('express')
//create an express router
const router = express.Router();
// Provides utilities for working with file and directory paths
const path = require('path');


//USE THE GET METHOD OF A BROWSER FORM
// Use sendFile() method to send the getlogin.html file as a response to the /getlogin route
// Use sendFile() method to send the getlogin.html file as a response to the /getlogin route
router.get('/getlogin', function (req, res, next) {
    // send html file directly to the browser
    // Right now we are in user.js which is in Routes directory
    //so our --dirname variable is the Routes directory
    console.log(__dirname);
    res.sendFile( `${__dirname}/getlogin.html`);

    // path.join(__dirname,'..', '/Views/getlogin.html')
})

//The getlogin.html file uses a get method form to send data
// Pass the queries from the getlogin.html form to the /getloginMessage subroute
// by specifying the /getloginMessage action attribute in the getlogin.html form
// Create the getlogin.pug file
//render the getlogin.pug file template to the client on the '/getloginmessage' subroute
router.get('/getloginMessage', function (req, res, next) {
    res.render('getlogin', {
        title: 'GETLogin' ,
        username: req.query.username, //username is the name of the html username form element
        password: req.query.password //password is the name of the html password form element
    });

})


//USE THE POST METHOD OF A BROWSER FORM

// Use sendFile() method to send the login.html file as a response to the / subroute
router.get('/', function (req, res, next) {
    // Use path.join to join different path segments together
    // This displays the login.html file in the Views folder
    console.log(path.join(__dirname,'..', '/Views/login.html'))
    res.sendFile( path.join(__dirname,'..', '/Views/login.html'));

})

// To send a post to the server, you must install and require 'body-parser'
// You must also create a bodyParser middleware to parse the posted request body in the main js file
// You must also set login.html form action to proper url (user/login) and method as post
router.post('/login', function (req, res, next) {
    // log the posted data to the console
    console.log(req.body);
    // render the login.pug template file to the browser
    res.render('login', { title: 'Login' , message : 'Hello ' + req.body.username +' Login Successful'
    });
})

//Export router object and require it in main js file
module.exports = router;