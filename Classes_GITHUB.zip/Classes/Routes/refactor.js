// REFACTORING STEPS TO CREATE MOUNTABLE ROUTE HANDLER

// Require express
// Create a new express router object
// and assign it to a constant "router"
// Create all your sub-routes
// Do not forget to export your route handler

//Require express
const express = require ('express')

//create a new express router object
// A Router instance is a complete middleware and routing system
const router = express.Router();

// CREATE SUB-ROUTES

router.get('/', function (req, res, next) {
    // send content directly to the browser (not using a template) - this can be tedious
    res.send('<html><head><title>Examples Index</title> <link rel="stylesheet" href="/bw/quartz/bootstrap.css" /></head>' +
        '<body class="container"><h1>Examples</h1><ul>' +
        '<li><a href="/examples/simple-code/">Simple Server Code examples</a></li>' +
        //TODO: Add once form-example.hbs is created
        //'<li><a href="/examples/form/">GET Simple Form Example</a></li>' +
        '</ul></body>')
})

//Render the base.pug template to the client on the '/pug' route
//To render static files, create the public folder with (css and img subfolders)
//Then in the driver file (6refactor.js) create a middleware to include static files
// Use render() method to render templates
router.get('/pug', function (req, res) {
    res.render('base', { title: 'Base Template'});
})


//USING FETCH (with node-fetch) -
router.get('/fetch', async function  (req, res) {

    //Ensure you read the API documentation to understand which URL to use
    const url = 'https://dog.ceo/api/breeds/image/random' //assign the API URL to variable url
    //specify the required option object properties
    const options = {
        "method": "GET", //Action type
        //body: JSON.stringify(body),
        "headers": {'Content-Type': 'application/json'} //This is used when a json object is expected
    }

//Await the result from fetch, then assign it to the response variable as a json object

    const response = await fetch(url,options)
        .then(res => res.json())
        // Catch any errors using .catch() promise (call back) and log it in the console
        .catch(e => {
            console.error({

                error: e
            })
        });
    console.log(response) // if no error, log the response

    //Pick just the url from the json object (in this case it's the message property)
    //Render the picture using the pug template (pug template should accept the imgURL variable)
    res.render('base', { title: 'Base Template', imgURL: response.message});
})


//EXPORT THE ROUTER OBJECT
module.exports = router;



