//USER AUTHENTICATION USING PASSPORT
//We will use a local strategy in this class
// Local means authentication is confirmed against the database or in our case an array
//You can also use other 3rd party authentication (e.g. facebook, github, etc)
//install passport and a passport local strategy (npm i passport  and npm i passport-local)
// Require passport in the main app file
// then use the middleware between the express session middleware and route middleware


//Require express
const express = require ('express')
//create an express router
const router = express.Router();
//Require passport
const passport = require('passport');
//Import the passport local strategy from the local.js file
const localStrategy = require('./strategies/local.js');


// ensure to include passport.authenticate("local") between the route and the function
router.post('/api/auth',passport.authenticate("local"), function (req, res, next) {
       res.send("authentication ok")
    console.log(req.session)
})

// create a status route to show that after user validation and serialization
// Each subsequent route visit calls deserializer which attaches the authenticated user to the request object
// It checks to ensure the user remains authenticated after each subsequent website visit
// session and request.user are still accessible
router.get('/api/status', function (req, res, next) {
    console.log(`In the api/status route. session is:`)
    console.log(req.session)
    //if user exists in request object return the user
    if (req.user) return res.send(req.user)
    // if user does not exists in request object, return message
    else return res.send("User not found in request body")
})
module.exports = router;