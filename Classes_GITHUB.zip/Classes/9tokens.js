// JWT TOKENS
/*
JWT tokens are used for authentication (just like express passport).
However, unlike passport that can only be used in node.js, JWT can be used for authentication in various
server-side website technologies.
Create a jwt token (using a username, password and secret), attach it to a cookie,
create a middleware to verify the signed token whenever a members-only page is being accessed (in auth.js file)
 */

//Require express
const express = require ('express')
//create an express router
const router = express.Router();

// Require path
const path = require('path');
//Require bcrypt for encrypting passwords
bcrypt = require ('bcryptjs')
//Require jsonwebtoken
const jwt = require('jsonwebtoken')
// assign the validator object using destructuring and require express-validator
const {check, validationResult} = require ('express-validator')
const bodyParser = require('body-parser');
//Create a bodyParser middleware to parse the posted body
router.use(bodyParser.urlencoded({ extended: false }))
router.use(bodyParser.json())

//Create a html signup form
// Create a welcome pug file
// create a /signup route in 6refactor.js and refactor here
// Ensure body-parser is required in main startup file - 6refactor.js
// Ensure you install and require bcryptjs
// Install and require express-validator
//Install and require jsonwebtoken




// Use sendFile() method to send html file when sub-route is accessed
router.get('/',  function (req, res, next) {
    // send html file directly to the browser
    res.sendFile( `${__dirname}/Routes/signup.html`);
})

//Create a function signToken() that creates a jwt signature
//signToken takes username and password parameters
// jsonwebtoken.sign() function takes a payload (username and password), a secret string, and options parameters
const signToken = (name, password) =>{
    return jwt.sign({name: name, password:password}, 'This is a secret',
        {expiresIn: '90d'});

}

//Validate the login data coming with the request.body object
router.post('/', [
    check('name')
        .not().isEmpty()
        .withMessage('Please enter a name')
        .isLength({min: 3, max: 50})
        .withMessage('Name must be at least 3 characters')
        .isAlpha()
        .withMessage('Name must contain only alphabets'),
    check('email')
        .not().isEmpty()
        .withMessage('Please enter Email')
        .isEmail()
        .withMessage('Invalid Email'),

    check('password')
        .not().isEmpty()
        .withMessage('Please enter password')
        .isLength({min: 8})
        .withMessage('Password must be 8 or more digits')
        .isStrongPassword()
        .withMessage('Password must contain lowercase, uppercase and numbers')

], (req, res, next)  => {

    // return validation errors in an array if any exist
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(422).json({
            errors: errors.array()});
    }

    //use bcrypt.hash() to encrypt the password with a cost of 12 - this returns a promise
    const password = bcrypt.hash(req.body.password, 12)
    //Use the .then chain  to create a function that specifies what you want to happen to the data
    // returned by the promise

    password.then(function(data) {
        //console.log(data)

   // Pass the name and encypted password into the signToken() function and get a signed token
    const token =signToken(req.body.name, data )

   // console.log(token)

    //Create a cookie with the signed token
    res.cookie('token', token, {httpOnly: true, maxAge: 86400000});
    // render the welcome pug file
    res.render('welcome',{username: req.body.name});

    })

})



module.exports = router;
