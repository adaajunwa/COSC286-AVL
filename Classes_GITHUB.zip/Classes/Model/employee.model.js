const mongoose = require('mongoose');

const EmployeeSchema = mongoose.Schema(
    {
        name:{
            type: String,
            required: [true, "Please enter a name"],
        },
        email:{
            type: String,
            required: [true, "Please enter a valid email"],
            unique: true
        },
        age:{
            type: Number,
            required: false,
        },
        Salary:{
            type: Number,
            required: true,
            default: 200
        }
    },
    {
        timestamps: true, // creates 2 other fields for Created At and Updated At
    }
)

const Employee = mongoose.model("Employee", EmployeeSchema)

// Export the EmployeeSchema model
module.exports = Employee
// Ensure you require it in the main apps.js file
// Create and employee route handler for creating/posting new employees (api/employee)
