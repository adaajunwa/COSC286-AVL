//Require express and fs
const express = require ('express')
const fs = require('fs');

//create an express router
const router = express.Router();
//Require jsonwebtoken
//const jwt = require('jsonwebtoken')

//Read JSON file and parse it to a javascript object
const tours = JSON.parse(fs.readFileSync(`${__dirname}/../data/tours-simple.json`));
//Import the JWT Authenticator from the auth.js file
const cookieJwtAuth = require('../auth.js');
//Create a middleware to ensure only users with the jwt token cookie can access the /product sub route
/*exports.cookieJwtAuth = (req, res, next) => {
    const token= req.cookies.token;
    try {
        const user = jwt.verify(token, process.env.SECRET);
        req.user = user;
        next()
    } catch{
        res.clearCookie('token');
        return res.redirect('/signup');

    }
} */

// getAllProduct function sends a response with tours data to client
//define the sub-route ('/') for the product route and handler function for the get() method
router.get('/', function (req, res) {
    res.status(200).json({
        status: 'success',
        data: {tours: tours}
    });
})

router.get('/users', cookieJwtAuth,function (req, res, next) {
    // send html file directly to the browser
    res.render( 'products');
    //console.log(req.headers);

})

router.get('/unauthorized',function (req, res, next) {
    // send html file directly to the browser

    res.sendFile( `${__dirname}/unauthorized.html`);
})
module.exports = router;