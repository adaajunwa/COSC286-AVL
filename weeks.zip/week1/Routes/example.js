//Require express
const express = require ('express')
// Require node-fetch for API fetch
const fetch = require('node-fetch');

//create an express router
const router = express.Router();

router.get('/', function (req, res, next) {
    // send content directly to the browser (not using a template) - this can be tedious
    res.send('<html><head><title>Examples Index</title> <link rel="stylesheet" href="/bw/quartz/bootstrap.css" /></head>' +
        '<body class="container"><h1>Examples</h1><ul>' +
        '<li><a href="/examples/simple-code/">Simple Server Code examples</a></li>' +
        //TODO: Add once form-example.hbs is created
        //'<li><a href="/examples/form/">GET Simple Form Example</a></li>' +
        '</ul></body>')
})

//Render the base.pug html template to the client on the '/pug' route
// Use render() method to render templates
router.get('/pug', function (req, res) {
    res.render('base', { title: 'Base Template'});
})

//Render the extendbase.pug html template to the client on the '/pug/extendbase' route
// Use render() method to render templates
router.get('/pug/extendbase', function (req, res) {
    res.render('extendbase' , { title: 'ExtendedBase Template'});
})

//Render the firs.pug html template to the client on the '/pug/first' route
// substitute title and message with values at runtime
 router.get('/pug/first', function (req, res) {
    res.render('first', { title: 'Templates' , message : 'My first template'
    });
})

router.get('/pug/simple-code', function (req, res, next) {
    // some simple logic to generate a random number from 0 to 5
    let rnd = Math.floor(Math.random()*5);
    // call the  render function to open the simple-code template
    // in the options send in as many parameters as you want
    // the options parameters can then be used in the template using the moustache syntax  i.e {{ variable }}
    res.render('simple-code', {
        title: 'Simple Server Code examples', // title used by the layout.hbs - appears at the top the page
        myName: 'Ada Ajunwa',
        myPosition: 'Instructor',
        randomNum: rnd, // use the random number generated above to display on the page
        randomIsEven: rnd % 2 === 0, // check if the random number is even and set a boolean variable
        names: ['Aaron', 'Betty', 'Carl', 'Debby'] // arrays and objects can also be sent to the template
    })
})

//USING FETCH (with node-fetch) - 
router.get('/fetch', async function  (req, res) {

    const url = 'https://dog.ceo/api/breeds/image/random'
    const options = {
        "method": "GET", //Action type
        //body: JSON.stringify(body),
        "headers": {'Content-Type': 'application/json'} //This is used when a json object is expected
    }
//Await the result from fetch, then assign it (res.json) to res
// Catch any errors using .catch
    const response = await fetch(url,options)
        .then(res => res.json())
        //console.log(res.json)
        // })
        .catch(e => {
            console.error({
                "message": "Oh No!",
                error: e
            })
        });
    console.log(response)

    //Pick just the url from the json object (in this case it's the message attribute)
    //Render the picture using the pug template
    res.render('base', { title: 'Base Template', imgURL: response.message});
    //res.send(response.message)

})

//FETCH MULTIPLE OBJECTS IN AN ARRAY FROM AN API
router.get('/multifetch', async function  (req, res) {

    const url = 'https://dog.ceo/api/breeds/image/random/3' //gets 3 random images
    const options = {
        "method": "GET", //Action type
        //body: JSON.stringify(body),
        "headers": {'Content-Type': 'application/json'} //This is used when a json object is expected
    }
//Await the result from fetch, then assign it (res.json) to res
// Catch any errors using .catch
    const multiResponse = await fetch(url,options)
        .then(res => res.json())
        .catch(e => {
            console.error({
                "message": "Oh No!",
                error: e
            })
        });
    //Map the message attribute from the json object
    let display  =  multiResponse.message.map((url) => {

        return `${url}`
    });
    console.log(multiResponse.message)

    //Pick just the url from the json object (in this case it's the message attribute)
    //Render the image array using the pug base template

   // res.send(display)
    res.render('multifetch', { title: 'multifetch', imgURLArray: display});

})
module.exports = router;