//Require express
const express = require ('express')
//require path
const path = require('path')
// Import the Employee model
const Employee = require (path.join(__dirname,'..', '/Model/employee.model.js'))
//create an express router
const router = express.Router();


//This route will create an employee collection in the Database we specified within our connection string (if it does not exist)
// It will also add documents to our collection
router.post('/employee', async function (req, res, next) {
    // log the posted data to the console
    console.log(req.body);
    try{
       const employee =  await Employee.create(req.body);
       res.status(200).json(employee);
    }catch(err){
        res.status(500).json({message: err.message});
    }
    });

// This route will get all documents from our employee collection
router.get('/employee', async function (req, res, next) {
    // log the posted data to the console
    try{
        const employees =  await Employee.find({});
        res.status(200).json(employees);
    }catch(err){
        res.status(500).json({message: err.message});
    }
});

// This route will get documents from our employee collection specified by the id field
router.get('/employee/:id', async function (req, res, next) {
    // log the posted data to the console
    try{
        const { id } = req.params;
        const employee = await Employee.findById(req.params.id);
        res.status(200).json(employee);
    }catch(err){
        res.status(500).json({message: err.message});
    }
});

// This route will delete documents from our employee collection specified by the id field
router.delete('/employee/:id', async function (req, res, next) {
    // log the posted data to the console
    try{
        const { id } = req.params;
        const employee = await Employee.findByIdAndDelete(id);
        if (!employee) {
            return res.status(404).json ({message:'User not found'});
        }

        const updatedEmployee = await Employee.findById(id);
        res.status(200).json({message:'Employee Deleted Successfully'});
    }catch(err){
        res.status(500).json({message: err.message});
    }
});

// This route will update documents in our employee collection specified by the id field
router.put('/employee/:id', async function (req, res, next) {
    // log the posted data to the console
    try{
        const { id } = req.params;
        const employee = await Employee.findByIdAndUpdate(id, req.body);
        if (!employee) {
            return res.status(404).json ({message:'User not found'});
        }

        const updatedEmployee = await Employee.findById(id);
        res.status(200).json(updatedEmployee);
    }catch(err){
        res.status(500).json({message: err.message});
    }
});

// Classwork: Try the patch method


//FILTER BY QUERY
router.get('/employee_filter', async function (req, res, next) {
  // const filter =
  console.log(req.query)
    // log the posted data to the console
    try{
      //Filter directly from query string
       //const employees =  await Employee.find(req.query);
       //Filter explicitly using Mongoose syntax. you can pull query properties and values from req.query object
       /* const employees =  await Employee.find()
            .where('name')
            .equals('Pete');
        */
        /* const employees =  await Employee.find()
            .where('Salary')
            .lte('200'); //less than or equal to (lt is less than, gt is greater than)

         */
        //Destructure to exclude elements from req.query object
        const queryObj = {...req.query}
        console.log(queryObj)
        // Specify field for query exclusion
        const excludedFields = ['Salary']
        //Delete excluded field from queryObj
        excludedFields.forEach(ele => delete queryObj[ele] )
        console.log(queryObj)
        const employees =  await Employee.find(queryObj);


        //Send response status and employee info
        res.status(200).json(employees);
    }catch(err){
        res.status(500).json({message: err.message});
    }
});

//SORT DATA
router.get('/employee_sort', async function (req, res, next) {


    // log the posted data to the console
    try{

        //Destructure to exclude elements from req.query object
        const queryObj = req.query
        const allEmployees =   Employee.find({});// Returns all data

        //Sort Data
        if (req.query.sort) {
            console.log("req.query.sort is " + req.query.sort)
            const employees =  allEmployees.sort(req.query.sort) //For desc, add a "-" before Salary

            const sorted = await employees
            console.log(sorted)
            //Send response status and employee info
            res.status(200).json(sorted);
        }
    }catch(err){
        res.status(500).json({message: err.message});
    }
});

module.exports = router;