//Require express
const express = require ('express')
//create an express router
const router = express.Router();


// Use sendFile() method to send html files
router.get('/', function (req, res, next) {
    // send html file directly to the browser
    res.sendFile( `${__dirname}/login.html`);
})

// Use sendFile() method to send html file to getlogin
router.get('/getlogin', function (req, res, next) {
    // send html file directly to the browser
    res.sendFile( `${__dirname}/getlogin.html`);
})

// Pass the queries from the getlogin.html file form
//render the getlogin.pug file template to the client on the '/getloginmessage' subroute
router.get('/getloginMessage', function (req, res, next) {
    res.render('getlogin', {
        title: 'GETLogin' ,
        username: req.query.username,
        password: req.query.password
    });

})

// Use sendFile() method to send html files
// To send a post to the server, you must install and require 'body-parser'
// You must also create a bodyParser middleware to parse the posted body
// You must also set html form action to proper url and method as post
router.post('/login', function (req, res, next) {
    // log the posted data to the console
    console.log(req.body);
    // send html file directly to the browser
    res.render('login', { title: 'Login' , message : 'Hello ' + req.body.username +' Login Successful'
    });
})
module.exports = router;