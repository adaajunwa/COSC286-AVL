//USER AUTHENTICATION USING PASSPORT
//We will use a local strategy in this class
// Local means authentication is confirmed against the database or in our case an array
//You can also use other 3rd party authentication (e.g. facebook, github, etc)
//install passport and a passport local strategy (npm i passport  and npm i passport-local)
// Require passport in the main app file
// then use the middleware between the express session middleware and route middleware


//Require express
const express = require ('express')
//create an express router
const router = express.Router();
//Require passport
const passport = require('passport');
//Import the passport local strategy from the local.js file
const localStrategy = require('./strategies/local.js');


// ensure to include passport.authenticate("local") between the route and the function
router.post('/api/auth',passport.authenticate("local"), function (req, res, next) {
       res.send("ok")
})

// create a status route to understand how deserializer attaches the user id to the session
router.get('/api/status',passport.authenticate("local"), function (req, res, next) {
    console.log(`In the api/status route. session is:`)
    console.log(req.session)
    res.send(req.user)
})
module.exports = router;