// Configure a local passport authentication strategy to validate the user
// How Passport works: First when user signs in, it validates the posted username and password using passport.use()
// then it goes into serializeUser() to insert the user into the session
// then whenever user accesses another route, it goes to deserilizeUser() to search that the user exists

// require passport
const passport = require('passport')
//require local passport strategy class
const Strategy = require('passport-local')
const mockUsers = require("../Users");

// Dont forget to serialize the user into the session using passport.serializeUser()
// it takes the user object we just validated and stores it in a session
// It takes a callback function as parameter. This in turn takes the user object and the done() function
//This done function takes 2 parameters: err and a unique value from the user object (id or username)

passport.serializeUser((user, done) => {
    console.log(`inside serializedUser. user object is:`);
    console.log(user)
    done(null,user.id)
})

// Then deserialize the user using passport.deserializeUser()
// looks up the the user property (from the done() function in passport.serializeUser()) in the session,
// and uses it to search for the user, then attaches the user to the request object
//  It takes a callback function as parameter. This in turn takes the user property passed into the done
//  function of the serialiseUser() function, and the done function
passport.deserializeUser((id, done) => {
    console.log(`inside deserializedUser. user id: ${id}`);
    try{
        //Find the user and password from mockUsers, make sure they exist
        const findUser = mockUsers.find((user) => user.id === id)
        // If user object is not found throw exception to be caught in the catch section
        if (!findUser) {throw new Error ('User not found');}
        //if user exists and password is correct call the done function
        //the done() function which takes 2 parameters an error and a user value
        done(null, findUser)

    }
    catch(err){
//call done when catching the error too
        done(err, null)
    }
})


// tell passport to use our Strategy class
// Strategy takes 2 parameters: options and a callback verification function
//The verification function takes 3 parameters: username, password and a done call back function
// if we are using an email instead of a password to authenticate, we would need to specify this in options
// specify that usernameField should be email property from the req.body
// passport.use(new Strategy({usernameField:"email"},(username, password, done) =>{}))

const local = passport.use(new Strategy({},(username, password, done) =>{

// logs
    console.log(`Inside passport validator: username, password is ${username} and ${password}`)
// Wrap in try-catch to handle errors
try{
    //Find the user and password from mockUsers, make sure they exist
    const findUser = mockUsers.find((user) => user.username === username)

    // If user object is not found throw exception to be caught in the catch section
    if (!findUser) {throw new Error ('User not found');}
    //if password does not match, throw error
    if (findUser.password !== password) {throw new Error ('Invalid Credentials');}
    //if user exists and password is correct call the done function
    //the done() function takes 2 parameters an error and a user value

    done(null, findUser)
    console.log(`user object is: `);
    console.log(findUser)
 }
catch(err){
//call done when catching the error too
    done(err, null)
}
}))

//ensure you export the passport.use function into the actual passport route js file
module.exports = local;