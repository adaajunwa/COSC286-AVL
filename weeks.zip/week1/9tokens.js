// Server-side Validation

//Require express
const express = require ('express')
//create an express router
const router = express.Router();
// Do not forget to install multer package "npm i multer"
// Multer allows us to manage files upload from client to the server file system
// Create a folder images on the server file system to hold these uploads
// Create the upload.html file, include enctype="multipart/form-data" as a property in the form
// Require path
const path = require('path');
//Require bcrypt for encrypting passwords
bcrypt = require ('bcryptjs')
//Require jsonwebtoken
const jwt = require('jsonwebtoken')
// assign the validator object using destructuring and require express-validator
const {check, validationResult} = require ('express-validator')
const bodyParser = require('body-parser');
//Create a bodyParser middleware to parse the posted body
router.use(bodyParser.urlencoded({ extended: false }))
router.use(bodyParser.json())

//Create a html validation form
// create a /validation route in 6refactor.js and refactor here
// Setup public css and client.js files
// Ensure body-parser is required in main startup file - 6refactor.js
// Install and require express-validator

const signToken = (name, password) =>{
   return jwt.sign({name: name, password:password}, 'This is a secret',
        {expiresIn: '90d'});

}

// Use sendFile() method to send html files
router.get('/',  function (req, res, next) {
    // send html file directly to the browser
    res.sendFile( `${__dirname}/Routes/signup.html`);
})

// Use sendFile() method to send html files
//Add upload.single to show we will upload a single file per time
//Specify the name of the html form input element that will hold the path (images)
router.post('/', [
    check('name')
        .not().isEmpty()
        .withMessage('Please enter a name')
        .isLength({min: 3, max: 50})
        .withMessage('Name must be at least 3 characters')
        .isAlpha()
        .withMessage('Name must contain only alphabets'),
    check('email')
        .not().isEmpty()
        .withMessage('Please enter Email')
        .isEmail()
        .withMessage('Invalid Email'),

    check('password')
        .not().isEmpty()
        .withMessage('Please enter password')
        .isLength({min: 8})
        .withMessage('Password must be 8 or more digits')
        .isStrongPassword()
        .withMessage('Password must contain lowercase, uppercase and numbers')

], (req, res, next)  => {


    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(422).json({
            errors: errors.array()});
    }
    //Ensure you install bcryptjs and require bcryptjs
    //use bcrypt.hash() to encrypt the password with a cost of 12 - this returns a promise
    const password = bcrypt.hash(req.body.password, 12)
    //specify what you want to happen to the data returned by the promise using the .then chain
    //to create a function (console log the promised encrypted password)
    password.then(function(data) {
        console.log(data)



    //Install and require jsonwebtoken
    // jsonwebtoken.sign() takes a payload, secret string, and
    const jwtExpires = '90d';
    const token =signToken(req.body.name,req.body.password )
     // console log and send response to the client to complete the request response cycle
   console.log(token)
    //res.send(  `token ${token} has been encoded successfully`);
    res.cookie('token', token, {httpOnly: true, maxAge: 86400000});

    res.render('welcome',{username: req.body.name});


    })
})



module.exports = router;
