// Create a folder named routes
// create a product.js, example.js and user.js file under it
// USING EXPRESS
//Require fs
const fs = require('fs');
// Require the body-parser function
const bodyParser = require('body-parser');

//const cors =require('cors')
//Require cookie-parser
//const cookieParser = require('cookie-parser');
//Require express-session
const session = require('express-session');
//Require passport
const passport = require('passport');
//
// Require the express function
const express = require('express');
// Require path for rendering static files
const path = require('path');
//Call the express function and assign it to app
const app = express();
// Require the .env config file
require('dotenv').config()
// Require mongoose
const mongoose = require('mongoose');

//Create a bodyParser middleware to parse the posted body
app.use(bodyParser.urlencoded({ extended: false })) // for form elements
app.use(bodyParser.json()) // for json objects

//Import the connectDB function from the 9VMongoDB.js file
const connectDB = require ('./9VMongoDB.js');

//Import the Router from the employees.js file
const employeeAPIRouter = require('./Routes/employees.js');
//Import the Router from the product file
const productRouter = require('./Routes/product.js');
//Import the Router from the example.js file
const exampleRouter = require('./Routes/example.js');
//Import the Router from the user.js file
const userRouter = require('./Routes/user.js');
//Import the Router from the 7multer.js file
const uploadRouter = require('./7multer.js');
//Import the Router from the 8Acookies.js file
const cookieRouter  = require('./8Acookies.js');
//Import the Router from the 8Bsessions.js file
const sessionRouter  = require('./8Bsessions');
//Import the Router from the 8Cpassport.js file
const passportRouter  = require('./8Cpassport.js');
//Import the Router from the 8validation.js file
const validationRouter = require('./8validation.js');
//Import the Router from the 9tokens.js file
const signupRouter = require('./9tokens.js');
// Create middleware to include STATIC FILES
//'/image' is the alias name for your url route from the working directory (--dirname)
//'/public/img' is the exact file path
app.use('/image', express.static (__dirname+'/public/img'));
app.use('/css', express.static (__dirname+'/public/css'));
// OR you could include static files directly from public with this format
app.use(express.static (__dirname+'/public'));

// Connect to MongoDB
 connectDB()

//Open the MongoDB connection and Start a Server
mongoose.connection.once('open', function(){
    console.log('MongoDB Connected');
    // listen method takes port, host IP and callback function as arguments
    let port =8080
    app.listen(port, ()=>{
        console.log(`Server started on port ${port}`);
    })
})

/* let port =8080
app.listen(port, ()=>{
    console.log(`Server started on port ${port}`);
}) */


app.use(express.json())
// use cookieParser middleware
//app.use(cookieParser());

//use session middleware
app.use(session({
    secret: "this is a secret key",
    saveUninitialized: false, //do not save uninitialised sessions to memory.
                              // A session is uninitialized when it is new but not modified.
                              // Choosing false is useful for implementing login sessions,
                              // reducing server storage usage
    resave: false, //do not resave unmodified sessions back to store
    cookie:{
        maxAge: 60000 * 10
    }
}))
// initialize and the passport and passort session middlewares
app.use(passport.initialize());
app.use(passport.session())

//DEFINE ROUTES
//create express routers as middlewares for the product and example routes
//Middleware is a function that can modify the incoming request data
//app.use(cors)
app.use('/api', employeeAPIRouter)
app.use('/product', productRouter)
app.use('/example', exampleRouter)
app.use('/user', userRouter)
app.use('/upload', uploadRouter)
app.use('/cookie', cookieRouter)
app.use('/session', sessionRouter)
app.use('/passport', passportRouter)
app.use('/validation', validationRouter)
app.use('/signup', signupRouter)


// TEMPLATES
//set up view engine for html templates
// Set template type as pug
app.set('view engine', 'pug');
// Create views folder
// set folder where pug should find templates
app.set('views', `${__dirname}/views`);
//create base.pug in the views folder

module.exports = app;



