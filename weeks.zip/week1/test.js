const express = require('express');
const fs = require('fs');
//Call the express function and assign it to app
const app = express();


let port =8080
app.listen(port, ()=>{
    console.log(`Server is started on port ${port}`);
})

app.get('/test', function (req, res) {
    // send content directly to the browser (not using a template) - this can be tedious
    //res.send('hello')
    res.render('first', { title: 'Templates' , message : 'My first template'
    });
})




// Set template type as pug
app.set('view engine', 'pug');
// Create views folder
// set folder where pug should find templates
app.set('views', `${__dirname}/views`); //Root directory/views
//create base.pug in the views folder// Set template type as pug
// app.set('view engine', 'pug');
// // Create views folder
// // set folder where pug should find templates
// app.set('views', `${__dirname}/views`);
// //create base.pug in the views folder