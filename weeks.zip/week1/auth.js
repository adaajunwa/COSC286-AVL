const jwt = require('jsonwebtoken')

//Create a middleware to ensure only users with the jwt token cookie can access the /product sub route
cookieJwtAuth = (req, res, next) => {

    try {
        let token =req.headers.cookie.split ("=")[1]
        if (token && jwt.verify(token, 'This is a secret')) {
            //token = req.headers.cookie.split ("=")[1]
            console.log(token)
        }
        if (!token){
            console.log(req.headers.cookie)
            //res.redirect('/signup');

        }

        next()
    } catch(e){
        console.log(e)
        res.status(401).redirect('/product/unauthorized');
        //res.clearCookie('token');
        //return res.redirect('127.0.0.1:8080/signup');

    }
}

module.exports = cookieJwtAuth;