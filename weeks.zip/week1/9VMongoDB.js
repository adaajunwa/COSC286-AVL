// MongoDB a NOSQL database stores data in collections not in relations like in an RDBMS
// Individual records in a collection are called documents
// They have a key/ value structure like JSON
// MongoDB is great for performance, flexibility and scalability
// Create a free MongoDB account (mongodb.com)
// On the Deploy Cluster Page ensure you pick "free", then
// Change your cluster name if you want, and click "CREATE DEPLOYMENT"
// Specify a database user and password, then click "Choose a Connection Method"
// On the Connect to Cluster page, click on Drivers
// Copy your connection string, and click ok
// Click on projects to view your projects page
//  name and Create a new project
// Create a database
// Create a collection
// Install mongodb (npm install mongodb)
//Install mongoose (npm i mongoose) mongoose is an ORM that makes working with mongoDB much easier
// WE WOULD USE A .ENV FILE (install dotenv)
// Create a .env file at the project root to save your connection string
// You must require the .env config in the main app.js file
// Add the connection string to the .env file
// in the .env file,update the password with the MongoDB password, and add the database name after "mongodb.net/"
// Create a Model folder in the under the project folder

const mongoose = require('mongoose');
require('dotenv').config();

//Connect to Mongodb via mongoose
// mongoose.connect() takes the connection string and an options object
// the options object properties set to true to prevent us from getting warnings from MongoDB
const connectDB = async() => {
    try {
        await mongoose.connect(process.env.DB_Connect);

    } catch (e) {
        console.log(e);
    }
}

module.exports = connectDB;
// Ensure connectDB and mongoose are required in the main app.js file
// and connected by calling this connection module (connectDB())

