//Node Package Manager (NPM)
//npm is used for installing nodejs packages and libraries. it comes preinstalled in nodejs
//initialize npm in the terminal using 'npm init'. This produces a package.json file which describes
// the project. Answer each question, then hit enter
// Install nodemon (allows for seamless starting and updating of our webserver)
// use 'npm i nodemon'
// Install express 'npm i express'. A new folder with all relevant express modules is created
// and express is included as a dependency in the package.json file
