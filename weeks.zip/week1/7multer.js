//Require express
const express = require ('express')
//create an express router
const router = express.Router();
// Do not forget to install multer package "npm i multer"
// Multer allows us to manage files upload from client to the server file system
// Create a folder images on the server file system to hold these uploads
// Create the upload.html file, include enctype="multipart/form-data" as a property in the form
// Require path
const path = require('path');
// Require multer function
const multer = require('multer');
// Require fs-extra "extends node.js file system methods"
const fse = require('fs-extra')

//To move files from one directory to another in express, use fs-extra
// Install fs-extra (npm i fs-extra)
// Require fs-extra "fse = require('fs-extra')"

// use multer.diskStorage to manage and determine the specifications of our uploaded files
// it takes an object with various properties
/* const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, '/tmp/my-uploads')
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
    cb(null, file.fieldname + '-' + uniqueSuffix)
  }
}) */

const storage = multer.diskStorage({
    // The destination prop takes a call back function (cb)-- for the location to store files
    //cb takes an error argument and a file path argument
    destination:  (req, file, cb) => {
        cb(null, 'images')
    },
    // The filename prop takes a call back function (cb)-- for the unique filename for each file
    //cb takes an error argument and a filename path argument
    // current time stamp and encoded path of original uploaded file
    filename:  (req, file, cb) => {
        cb(null, Date.now() + ' ' +file.originalname);
    }

})
// create a multer middleware object called upload from 'storage' above
//limits object specifies the file size
const upload = multer({storage: storage,
    //Limits of the uploaded data
    limits: {
    // limit file size to 1MB -> 1024*1024
    fileSize: 1024*1024
},
    /* fileFilter() Function to control which files are accepted
        The function should call `cb` with a boolean to indicate if the file should be accepted
       To reject this file pass `false`, like so: cb(null, false)
       To accept the file pass `true`, like so: (null, true)
       You can always pass an error if something goes wrong: cb(new Error('I don\'t have a clue!')) */

    fileFilter: (req, file, callback) => {
           // check that mime type starts with 'image/'
           // mime is a standard that indicates the format of a file
        // get only documents with 'application/'
        // get only pdf 'application/pdf'
           if (file.mimetype.startsWith('image/')) {
               // callback returns true
               callback(null, true); // file mime type is allowed
           } else {
               // file not allowed, so return callback with new error message
               return callback(new Error('Only images are allowed'));
           }
       }
});



// Use sendFile() method to send html files
router.get('/', function (req, res, next) {
    // send html file directly to the browser
    res.sendFile( `${__dirname}/Routes/upload.html`);
})

// Use sendFile() method to send html files
//Add upload.single to show we will upload a single file per time
//Specify the name of the html form input element that will hold the path (images)
router.post('/', upload.single("image"), function (req, res, next) {
    // send text response directly to the browser
    res.send( 'Upload Successful');
    console.log(req.file.filename)
    // move file from temp source folder to public folder
    // Takes source, destination and an error callback function
    fse.move(`./images/${req.file.filename}`, `./public/img/${req.file.filename}`, err => {
       if (err) return console.error(err)
        console.log('File Moved Successfully!')
    })
})

// FOR MULTIPLE UPLOADS
// Use sendFile() method to send html files
router.get('/uploadMulti', function (req, res, next) {
    // send html file directly to the browser
    res.sendFile( `${__dirname}/Routes/uploadMulti.html`);
})

// Use sendFile() method to send html files
//Add upload.array to show we will upload an array of files per time
//Specify the name of the html form input element that will hold the path (images)
// Specify the maximum number of files to upload per time (3)
router.post('/uploadMulti', upload.array("images", 3), function (req, res, next) {
    // send html file directly to the browser
    res.send( 'Image Array Upload Successful');
})


module.exports = router;