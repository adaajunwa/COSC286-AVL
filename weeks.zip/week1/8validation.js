// Server-side Validation

//Require express
const express = require ('express')
//create an express router
const router = express.Router();
// Do not forget to install multer package "npm i multer"
// Multer allows us to manage files upload from client to the server file system
// Create a folder images on the server file system to hold these uploads
// Create the upload.html file, include enctype="multipart/form-data" as a property in the form
// Require path
const path = require('path');
// assign the validator object using destructuring and require express-validator
const {check, query, validationResult} = require ('express-validator')
//const {query, ValidationResult} = require ('express-validator')
const bodyParser = require('body-parser');
//Create a bodyParser middleware to parse the posted body
router.use(bodyParser.urlencoded({ extended: false }))
router.use(bodyParser.json())

//Create a html validation form
// create a /validation route in 6refactor.js and refactor here
// Setup public css and client.js files
// Ensure body-parser is required in main startup file - 6refactor.js
// Install and require express-validator


//When user accesses this path, send the html file
// Use sendFile() method to send html files
router.get('/',  function (req, res, next) {
    // send html file directly to the browser
    res.sendFile( `${__dirname}/Routes/validationForm.html`);
})

// Use sendFile() method to send html files
//Add upload.single to show we will upload a single file per time
//Specify the name of the html form input element that will hold the path (images)
// Always sanitize using .trim() before validating
// .bail() Stops running validations if any of the previous ones have failed.
router.post('/', [
    check('name')
        .trim()
        .not().isEmpty()
        .withMessage('Please enter a name')
        //.bail()
        .isLength({min: 3, max: 50})
        .withMessage('Name must be at least 3 characters')
        .isAlpha()
        .withMessage('Name must contain only alphabets'),
    check('email')
        .not().isEmpty()
        .withMessage('Please enter Email')
        .isEmail()
        .withMessage('Invalid Email'),
    // check phone
    check('phone')
        .trim()
        .not().isEmpty()
        .withMessage('Please enter phone number')
        .isInt()
        .withMessage('Phone number must be digits only')
        .isLength({min: 10, max: 10})
        .withMessage('Phone number must be 10 digits'),
    //Check radio button yes is selected
    check('age').equals('yes').withMessage('You must be 18 or greater'),

//Assignment zipcode
 //   check('zipcode')
  //      .isPostalCode('CA')
], (req, res, next)  => {

//validationResult extracts the validation errors from a request and makes them available in a Result object
    const errors = validationResult(req);
    //if errors exist
    if (!errors.isEmpty()) {
        //return status 422 and errors array as a json object
        return res.status(422).json({
            errors: errors.array()});
    }
    console.log(req.body.name);
    // send response to the client to complete the request response cycle
    res.send( 'Upload Successful');
})

// Use sendFile() method to send html file to getlogin
router.get('/query', function (req, res, next) {
    // send html file directly to the browser
    res.render( 'pugForm');
})

router.get('/queryMsg', [
    query('name')
        .trim()
        .not().isEmpty()
        .withMessage('Please enter a name')
        //.bail()
        .isLength({min: 3, max: 50})
        .withMessage('Name must be at least 3 characters')
        .isAlpha()
        .withMessage('Name must contain only alphabets'),
    query('email')
        .not().isEmpty()
        .withMessage('Please enter Email')
        .isEmail()
        .withMessage('Invalid Email'),
], (req, res, next)  => {

//validationResult extracts the validation errors from a request and makes them available in a Result object
    const errors = validationResult(req);
    //if errors exist
    if (!errors.isEmpty()) {
        //return status 422 and errors array as a json object
        return res.status(422).json({
            errors: errors.array()});
    }
    console.log(req.query.email);
    // send response to the client to complete the request response cycle
    res.send( 'Query Successful');
})

// Pass the queries from the getlogin.html file form
//render the pugForm.pug file template to the client on the '/queryMsg' subroute
/* router.get('/queryMsg', function (req, res, next) {
    res.render('getlogin', {
        title: 'GETLogin' ,
        username: req.query.username,
        password: req.query.password
    });

}) */
module.exports = router;